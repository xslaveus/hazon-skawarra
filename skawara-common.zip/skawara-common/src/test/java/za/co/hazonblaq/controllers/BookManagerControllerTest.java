package za.co.hazonblaq.controllers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import za.co.hazonblaq.interfaces.BookingManagerClient;
import za.co.hazonblaq.model.BookingSlot;

import java.time.LocalDateTime;
import java.util.List;

@SpringBootTest
public class BookManagerControllerTest implements BookingManagerClient {
    @Test
    public List<BookingSlot> getAvailableSlots() {
        return null;
    }

    @Test
    public BookingSlot pickBookingSlot(LocalDateTime timeSlot) {
        return null;
    }

    @Override
    public BookingSlot confirmBookingSlot(BookingSlot bookingSlot) {
        return null;
    }

    @Test
    public BookingSlot confirmBookingSlot(int bookingSlotId, boolean isSlotConfirmed) {
        return null;
    }

    @Test
    public BookingSlot enquireBookedSlot(int bookingSlotId) {
        return null;
    }

    @Test
    public BookingSlot cancelBooking(int bookingSlotId) {
        return null;
    }

    @Override
    public BookingSlot confirmBookingCancellation(BookingSlot bookingSlotCancellation) {
        return null;
    }

    @Test
    public BookingSlot confirmBookingCancellation(int bookingSlotId, boolean isSlotConfirmed) {
        return null;
    }
}