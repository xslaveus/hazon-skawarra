package za.co.hazonblaq;

//@SpringBootTest
public class ClientManagerControllerTest {/*

    @Autowired
    ClientManagementController clientManagementController;
    private static final Logger logger = LoggerFactory.getLogger(ClientManagementController.class);

    @Test
    public void AvailableSlots() {
        logger.info("client: getAvailableSlots()");
    }

    @Test
    public void retrieveAllClients() {
        logger.info("client: retrieveAllClients()");
        List<Client> clientList = clientManagementController.retrieveAllClients();

        for(Client client: clientList){
            logger.info("client: " + client.toString());
        }
    }
*/}