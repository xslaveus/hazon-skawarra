package za.co.hazonblaq;

public class Course {
}
