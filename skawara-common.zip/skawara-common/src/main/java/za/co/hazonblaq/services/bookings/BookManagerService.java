package za.co.hazonblaq.services.bookings;

import org.springframework.stereotype.Service;
import za.co.hazonblaq.interfaces.BookingManagerClient;
import za.co.hazonblaq.model.BookingSlot;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class BookManagerService implements BookingManagerClient {


    @Override
    public List<BookingSlot> getAvailableSlots() {
        return null;
    }

    @Override
    public BookingSlot pickBookingSlot(LocalDateTime timeSlot) {
        return null;
    }

    @Override
    public BookingSlot confirmBookingSlot(BookingSlot bookingSlotCnfirmation) {
        return null;
    }

    @Override
    public BookingSlot enquireBookedSlot(int bookingSlotId) {
        return null;
    }

    @Override
    public BookingSlot cancelBooking(int bookingSlotId) {
        return null;
    }

    @Override
    public BookingSlot confirmBookingCancellation(BookingSlot bookingSlotCancellation) {
        return null;
    }
}
