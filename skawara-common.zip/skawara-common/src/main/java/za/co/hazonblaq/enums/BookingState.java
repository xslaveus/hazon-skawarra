package za.co.hazonblaq.enums;

public enum BookingState {
    BOOKING_ACTIVE,BOOKING_PENDING_CONFIRMATION,BOOKING_CANCELED,BOOKING_NONE
}
