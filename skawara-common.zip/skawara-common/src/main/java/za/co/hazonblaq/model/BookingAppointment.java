package za.co.hazonblaq.model;

import java.io.Serializable;

public class BookingAppointment implements Serializable {
    private int clientId;
    private BookingSlot bookingSlot;

    public BookingAppointment(int clientId, BookingSlot bookingSlot) {
        this.clientId = clientId;
        this.bookingSlot = bookingSlot;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public BookingSlot getBookingSlot() {
        return bookingSlot;
    }

    public void setBookingSlot(BookingSlot bookingSlot) {
        this.bookingSlot = bookingSlot;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append("clientId:" + getClientId());
        if(getBookingSlot() != null){
            sb.append("bookingSlot:" + getBookingSlot());
        }
        return sb.toString();
    }
}
