package za.co.hazonblaq.model;

public class BookingRequirement {
    private int id;
    private double bookingAmount;

    public BookingRequirement(double bookingAmount) {
        this.bookingAmount = bookingAmount;
    }

    public double getBookingAmount() {
        return bookingAmount;
    }

    public void setBookingAmount(double bookingAmount) {
        this.bookingAmount = bookingAmount;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder();
        sb.append("id:"+getId());
        sb.append("bookingAmount:"+getBookingAmount());
        return sb.toString();
    }
}
