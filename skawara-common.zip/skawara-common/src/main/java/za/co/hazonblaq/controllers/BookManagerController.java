package za.co.hazonblaq.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;
import za.co.hazonblaq.interfaces.BookingManagerClient;
import za.co.hazonblaq.model.BookingSlot;
import za.co.hazonblaq.services.bookings.BookManagerService;

import java.time.LocalDateTime;
import java.util.List;

@RestController
public class BookManagerController implements BookingManagerClient {

    @Autowired
    BookManagerService bookManagerService;
    @Override
    public List<BookingSlot> getAvailableSlots() {
        return bookManagerService.getAvailableSlots();
    }

    @Override
    public BookingSlot pickBookingSlot(LocalDateTime timeSlot) {
        return null;
    }

    @Override
    public BookingSlot confirmBookingSlot(BookingSlot bookingSlotConfirmation) {
        return null;
    }

    @Override
    public BookingSlot enquireBookedSlot(int bookingSlotId) {
        return null;
    }

    @Override
    public BookingSlot cancelBooking(int bookingSlotId) {
        return null;
    }

    @Override
    public BookingSlot confirmBookingCancellation(BookingSlot bookingSlotCancellation) {
        return null;
    }
}
