package za.co.hazonblaq.interfaces;

import za.co.hazonblaq.model.Client;

import java.util.List;

public interface ClientInterface {

    Client createClient(Client client);
    Client updateClient(Client sourceClient, Client destClient);
    Client enableClient(Client client);
    Client disableClient(Client client);
    List<Client> listAllClients();
    Client getClientById(int id);
    Client getClientByName(String name);

}