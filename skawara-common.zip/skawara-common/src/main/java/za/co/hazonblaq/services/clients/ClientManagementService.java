package za.co.hazonblaq.services.clients;

import za.co.hazonblaq.interfaces.ClientInterface;
import za.co.hazonblaq.model.Client;
import za.co.hazonblaq.utils.MyCommonUtils;

import java.util.List;
import java.util.function.Predicate;

public class ClientManagementService implements ClientInterface {

    List<Client> clientList = MyCommonUtils.loadDefaultClients();
    @Override
    public Client createClient(Client client) {
        if(clientList.add(client)){
            client.setId(1);
            return client;
        }
        return null;
    }

    @Override
    public Client updateClient(Client sourceClient, Client destClient) {
        Client clientFound =
                clientList.stream().filter((c)->c.getId()==sourceClient.getId()).findFirst().get();
        clientList.remove(clientFound);
//         clientList.add(client);
        if(clientList.add(destClient)){
            destClient.setId(2);
            return destClient;
        }
        return null;
    }

    @Override
    public Client enableClient(Client client) {
        Client clientFound =
                clientList.stream().filter((c)->c.getId()==client.getId()).findFirst().get();
        clientList.remove(clientFound);
//         clientList.add(client);
        if(clientList.add(client)){
            client.setId(3);
            return client;
        }
        return null;
    }

    @Override
    public Client disableClient(Client client) {
         Client clientFound =
             clientList.stream().filter((c)->c.getId()==client.getId()).findFirst().get();
         clientList.remove(clientFound);
//         clientList.add(client);
        if(clientList.add(client)){
            client.setId(4);
            return client;
        }
        return null;
    }

    @Override
    public List<Client> listAllClients() {
        return clientList;
    }

    @Override
    public Client getClientById(int id) {
        return clientList.stream().filter((c)->c.getId()==id).findFirst().get();
    }

    @Override
    public Client getClientByName(String name) {
        return clientList.stream().filter((c)->c.getName().equalsIgnoreCase(name)).findFirst().get();
    }
}