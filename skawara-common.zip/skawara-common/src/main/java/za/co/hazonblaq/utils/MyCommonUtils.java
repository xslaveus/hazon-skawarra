package za.co.hazonblaq.utils;

import za.co.hazonblaq.model.Client;

import java.util.ArrayList;
import java.util.List;

public class MyCommonUtils {

    private static List<Client> listOfClients = null;

    public static List<Client> loadDefaultClients(){
        if(listOfClients == null)
        {
            String name="Dave";
            String surname="Cunningham";
            String cellNo="0430046924";
            String emailAddress="dave@gmail.com";
            Client client =  new Client(name, surname, cellNo, emailAddress);

            listOfClients.add(client);
             name="john";
             surname="manpowe";
             cellNo="0431234924";
             emailAddress="sdfgdsfg@gmail.com";
             client =  new Client(name, surname, cellNo, emailAddress);
            listOfClients.add(client);
        }
        return listOfClients;
    }
}
