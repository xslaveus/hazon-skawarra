package za.co.hazonblaq.interfaces;

import za.co.hazonblaq.model.BookingSlot;

import java.time.LocalDateTime;
import java.util.List;

public interface BookingManagerClient {

    List<BookingSlot> getAvailableSlots();
    BookingSlot pickBookingSlot(LocalDateTime timeSlot);
    BookingSlot confirmBookingSlot(BookingSlot bookingSlot);
    BookingSlot enquireBookedSlot(int bookingSlotId);
    BookingSlot cancelBooking(int bookingSlotId);
    BookingSlot confirmBookingCancellation(BookingSlot bookingSlotCancellation);
}
