package za.co.hazonblaq.model;

import java.io.Serializable;

public class Client implements Serializable {

    private int id;
    private String name;
    private String surname;
    private String emailAddress;
    private String cellNo;

    private boolean isActive;

    public Client(String name, String surname) {
        this.name = name;
        this.surname = surname;
    }

    public Client(String name, String surname, String cellNo) {
        this(name,surname);
        setCellNo(cellNo);
    }

    public Client(String name, String surname,String cellNo,String emailAddress) {
        this(name,surname,cellNo);
        setEmailAddress(emailAddress);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getCellNo() {
        return cellNo;
    }

    public void setCellNo(String cellNo) {
        this.cellNo = cellNo;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append("id:"+getId());
        sb.append("name:"+getName());
        sb.append("surname:"+getSurname());
        sb.append("emailAddress"+getEmailAddress());
        sb.append("cellNo:"+getCellNo());
        sb.append("isActive:"+isActive());

        return super.toString();
    }
}
