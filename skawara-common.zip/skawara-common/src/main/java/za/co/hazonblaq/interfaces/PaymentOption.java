package za.co.hazonblaq.interfaces;

public interface PaymentOption {
}
