package za.co.hazonblaq.model;

import za.co.hazonblaq.enums.BookingState;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class BookingSlot implements Serializable {

    private int bookingSlotId;
    private LocalDate bookingDate;
    private LocalDateTime bookingTimeStart;
    private LocalDateTime bookingTimeEnd;
    private String bookingDescription;
    private BookingState bookingState;
    private BookingLocation bookingLocation;
    private BookingRequirement bookingRequirement;

    public BookingSlot(LocalDate bookingDate,
        LocalDateTime bookingTimeStart, LocalDateTime bookingTimeEnd, String bookingDescription) {

        this.bookingDate = bookingDate;
        this.bookingTimeStart = bookingTimeStart;
        this.bookingTimeEnd = bookingTimeEnd;
        this.bookingDescription = bookingDescription;
    }

    public int getBookingSlotId() {
        return bookingSlotId;
    }

    public void setBookingSlotId(int bookingSlotId) {
        this.bookingSlotId = bookingSlotId;
    }

    public LocalDate getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(LocalDate bookingDate) {
        this.bookingDate = bookingDate;
    }

    public LocalDateTime getBookingTimeStart() {
        return bookingTimeStart;
    }

    public void setBookingTimeStart(LocalDateTime bookingTimeStart) {
        this.bookingTimeStart = bookingTimeStart;
    }

    public LocalDateTime getBookingTimeEnd() {
        return bookingTimeEnd;
    }

    public void setBookingTimeEnd(LocalDateTime bookingTimeEnd) {
        this.bookingTimeEnd = bookingTimeEnd;
    }

    public String getBookingDescription() {
        return bookingDescription;
    }

    public void setBookingDescription(String bookingDescription) {
        this.bookingDescription = bookingDescription;
    }

    public BookingState getBookingState() {
        return bookingState;
    }

    public void setBookingState(BookingState bookingState) {
        this.bookingState = bookingState;
    }

    public BookingLocation getBookingLocation() {
        return bookingLocation;
    }

    public void setBookingLocation(BookingLocation bookingLocation) {
        this.bookingLocation = bookingLocation;
    }

    public BookingRequirement getBookingRequirement() {
        return bookingRequirement;
    }

    public void setBookingRequirement(BookingRequirement bookingRequirement) {
        this.bookingRequirement = bookingRequirement;
    }

    @Override
    public String toString() {
        StringBuilder sb =  new StringBuilder();

        sb.append("bookingSlotId:"+getBookingSlotId());
        sb.append("bookingDate:"+getBookingDate());
        sb.append("bookingTimeStart:"+ getBookingTimeStart());
        sb.append("bookingTimeEnd:"+getBookingTimeEnd());
        sb.append("bookingDescription:"+getBookingDescription());

        if(getBookingState() != null) {
            //() ->  ? "hitch a ride": "run"
            sb.append(getBookingState().toString());
        }
        if(getBookingLocation()!=null) {
            sb.append(getBookingLocation().toString());
        }
        if(getBookingRequirement()!=null) {
            sb.append(getBookingRequirement());
        }
        return sb.toString();
    }
}
