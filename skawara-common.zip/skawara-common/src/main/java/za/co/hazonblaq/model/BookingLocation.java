package za.co.hazonblaq.model;

public class BookingLocation {

    private int id;
    private String bookingAddress;

    public BookingLocation(String bookingAddress) {
        this.bookingAddress = bookingAddress;
    }

    public String getBookingAddress() {
        return bookingAddress;
    }

    public void setBookingAddress(String bookingAddress) {
        this.bookingAddress = bookingAddress;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder();
        sb.append("id:"+getId());
        sb.append("bookingAddress:"+getBookingAddress());
        return sb.toString();
    }
}
