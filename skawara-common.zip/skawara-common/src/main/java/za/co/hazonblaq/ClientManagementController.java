package za.co.hazonblaq;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import za.co.hazonblaq.interfaces.ClientInterface;
import za.co.hazonblaq.model.Client;
import za.co.hazonblaq.services.clients.ClientManagementService;

import java.net.URI;
import java.util.List;

public class ClientManagementController{
    @Autowired
    ClientManagementService clientManagementService;

    @PostMapping("/clients/newclient")
    public ResponseEntity<Void>addNewClient(
        @PathVariable String studentId, @RequestBody Client newClient){

        /*            String name="Dave";
            String surname="Cunningham";
            String cellNo="0430046924";
            String emailAddress="dave@gmail.com";
            */

        Client client =  clientManagementService.createClient(newClient);

        if (client == null)
            return ResponseEntity.noContent().build();

        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path(
                "/{id}").buildAndExpand(client.getId()).toUri();

        return ResponseEntity.created(location).build();
    }

/*    public Client updateClient(@PathVariable String studentId, @RequestBody Client newClient) {
        return clientManagementService.updateClient(sourceClient, destClient);
    }*/

    @GetMapping("/clients/id/{id}/enable")
    public Client enableClient(@PathVariable("name") String name) {
        Client foundClient = clientManagementService.getClientByName(name);
        Client client = clientManagementService.enableClient(foundClient);

        return client;
    }

    @GetMapping("/clients/id/{id}/disable")
    public Client disableClient(@PathVariable("id") int id) {
        Client foundClient = clientManagementService.getClientById(id);
        Client client = clientManagementService.disableClient(foundClient);

        return client;
    }

    @GetMapping("/clients")
    public List<Client> retrieveAllClients() {
        List<Client> clientList = clientManagementService.listAllClients();

        return clientList;
    }

    @GetMapping("/clients/id/{id}")
    public Client getClientById(@PathVariable("id") int id) {
        Client client = clientManagementService.getClientById(id);

        return client;
    }

    @GetMapping("/clients/name/{name}")
    public Client getClientByName(@PathVariable("name") String name) {
        Client client = clientManagementService.getClientByName(name);

        return client;
    }
}
